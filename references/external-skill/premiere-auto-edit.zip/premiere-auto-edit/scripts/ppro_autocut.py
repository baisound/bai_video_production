#!/usr/bin/env python3
"""
ppro_autocut.py  —  AI動画編集パイプライン（無音カット → Premiere用XML ＋ テロップSRT）

【これは何】
動画を渡すと、AIで「無音カット済みのPremiereシーケンス(FCP7 XML/xmeml)」と
「テロップ(字幕SRT)」を出力する。Premiereで XML を読み込めばカット済みタイムラインが、
SRT を読み込めばテロップが入る。CEP/UXP/APIに依存しないので確実。

【経緯・要点（重要な学び）】
- Premiere Pro 2026 は AppleScript の DoScript 非対応 → CLIから直接スクリプト実行は不可。
  → よって「XMLインポート」ルートが最も確実（実機で動作確認済み）。
- タイムラインは必ず「フレーム単位」で前クリップ末尾に連結する（秒で積むと丸め誤差→隙間/字幕ズレ）。
- テロップ時刻は XML と"同一のフレーム計算"で出すと完全一致する（cut.mp4を介すと数フレームdrift）。
- 言い直し(リテイク)カットは意味理解が必要（LLM判定）。今は無音カットのみがデフォルト。
  → 余計な所まで切れるリスクがあるため、リテイクは別オプション/手動推奨。
- テロップは"単語レベル"タイムスタンプ(word_timestamps)で時刻を出す → 表示タイミングがズレない。
  カット(無音)区間に入る語は自動で除外し、句読点/字数/間/ブロック跨ぎで改行する。
- fpsはNTSC等に注意（テスト素材は 30000/1001 = 29.97）。

【依存】 ffmpeg / python3 / faster-whisper （いずれもこのMacに導入済み）

【使い方】
  python3 ppro_autocut.py --input "/path/to/movie.MP4"
  # オプション: --noise -30dB  --d 0.35  --pad 0.06  --maxchars 18  --model small  --outdir <dir>
  # 出力: <name>_autocut.xml , <name>_telop.srt （--outdir 省略時は入力と同じフォルダ）

【Premiereでの取り込み】
  1) ファイル → 読み込み → <name>_autocut.xml  （カット済みシーケンスが生成）
  2) <name>_telop.srt を読み込み → キャプションとしてシーケンスに追加
"""
import argparse, subprocess, re, os, sys

def f(t, fps): return int(round(t*fps))

def get_fps(src):
    r=subprocess.run(["ffprobe","-v","quiet","-select_streams","v:0",
        "-show_entries","stream=r_frame_rate","-of","default=noprint_wrappers=1:nokey=1",src],
        capture_output=True,text=True).stdout.strip()
    n,d=r.split("/"); return float(n)/float(d)

def get_dims(src):
    r=subprocess.run(["ffprobe","-v","quiet","-select_streams","v:0",
        "-show_entries","stream=width,height","-of","csv=p=0:s=x",src],
        capture_output=True,text=True).stdout.strip()
    w,h=r.split("x"); return int(w),int(h)

def get_duration(src):
    r=subprocess.run(["ffprobe","-v","quiet","-show_entries","format=duration",
        "-of","default=noprint_wrappers=1:nokey=1",src],capture_output=True,text=True).stdout.strip()
    return float(r)

def detect_silences(src,noise,d):
    err=subprocess.run(["ffmpeg","-hide_banner","-vn","-i",src,"-af",
        f"silencedetect=noise={noise}:d={d}","-f","null","-"],capture_output=True,text=True).stderr
    st=[float(x) for x in re.findall(r"silence_start: (-?[0-9.]+)",err)]
    en=[float(x) for x in re.findall(r"silence_end: ([0-9.]+)",err)]
    return list(zip(st,en))

def build_blocks(sil,total,fps,pad,minkeep):
    # keep = 無音の補集合（前後padだけ無音側を残す）
    keeps=[]; cur=0.0
    for s,e in sil:
        s2=min(max(s+pad,0),total); e2=min(max(e-pad,0),total)
        if s2>cur: keeps.append([cur,s2])
        cur=max(cur,e2)
    if cur<total: keeps.append([cur,total])
    keeps=[b for b in keeps if b[1]-b[0]>=minkeep]
    blocks=[]; run=0
    for b in keeps:
        sin=f(b[0],fps); sout=f(b[1],fps)
        if sout<=sin: continue
        blocks.append({"sin":sin,"sout":sout,"ts":run,"s0":b[0],"s1":b[1]}); run+=sout-sin
    return blocks, run

def make_xml(src,blocks,run,w,h,total_frames):
    import urllib.parse
    pathurl="file://"+urllib.parse.quote(src)
    fname=os.path.basename(src).replace("&","&amp;")
    R="<rate><timebase>30</timebase><ntsc>TRUE</ntsc></rate>"
    v=[];a=[]
    for i,b in enumerate(blocks):
        te=b["ts"]+b["sout"]-b["sin"]
        fb=(f'<file id="file1"><name>{fname}</name><pathurl>{pathurl}</pathurl>{R}<duration>{total_frames}</duration>'
            f'<media><video><samplecharacteristics><width>{w}</width><height>{h}</height></samplecharacteristics></video>'
            f'<audio><channelcount>2</channelcount></audio></media></file>') if i==0 else '<file id="file1"/>'
        v.append(f'<clipitem id="v{i}"><name>{fname}</name><duration>{total_frames}</duration>{R}<start>{b["ts"]}</start><end>{te}</end><in>{b["sin"]}</in><out>{b["sout"]}</out>{fb}<sourcetrack><mediatype>video</mediatype><trackindex>1</trackindex></sourcetrack></clipitem>')
        a.append(f'<clipitem id="a{i}"><name>{fname}</name><duration>{total_frames}</duration>{R}<start>{b["ts"]}</start><end>{te}</end><in>{b["sin"]}</in><out>{b["sout"]}</out><file id="file1"/><sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack></clipitem>')
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4">'
            f'<sequence id="seq1"><name>AI_AutoCut</name><duration>{run}</duration>{R}'
            f'<media><video><format><samplecharacteristics>{R}<width>{w}</width><height>{h}</height></samplecharacteristics></format><track>{"".join(v)}</track></video>'
            f'<audio><format><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics></format><track>{"".join(a)}</track></audio></media></sequence></xmeml>')

# 固有名詞などの誤認識を最終テロップ上で補正する置換辞書（必要に応じて追記）
SUBS={"りぃつけ":"りゅうすけ","りつけ":"りゅうすけ"}

def collapse_inline(s):
    # whisperのリピート暴走で行内が同一文字列の反復になる場合だけ畳む（正当な短い反復は温存）
    n=len(s)
    for p in range(4, n//2+1):           # 全体が period p の反復: "ABCABC"->"ABC"
        if n%p==0 and s==s[:p]*(n//p): return s[:p]
    for L in range(n//2, 3, -1):         # 隣接する同一チャンク(len>=4)の二重: "..XX.."->"..X.."
        for i in range(0, n-2*L+1):
            if s[i:i+L]==s[i+L:i+2*L]: return s[:i+L]+s[i+2*L:]
    return s

def transcribe_words(src,model):
    # 単語レベルのタイムスタンプ付きで文字起こし（テロップ時刻の精度UP）
    # condition_on_previous_text=False でリピート暴走（同フレーズ重複）を抑制
    from faster_whisper import WhisperModel
    m=WhisperModel(model,device="cpu",compute_type="int8")
    segs,_=m.transcribe(src,language="ja",vad_filter=True,word_timestamps=True,
                        condition_on_previous_text=False)
    words=[]
    for s in segs:
        if s.words:
            for w in s.words:
                t=w.word.strip()
                if t: words.append((w.start,w.end,t))
        else:  # word単位が取れなかったセグメントはセグメント全体で代用
            t=s.text.strip()
            if t: words.append((s.start,s.end,t))
    return words

def make_srt(words,blocks,run,fps,maxc):
    TOL=0.30  # 語開始がカット境界のこれ(秒)以内なら隣接ブロックにスナップ（先頭語ドロップ防止）
    def locate(t):
        # t が入るブロック→(i,t)。入らなければTOL以内で最近接にスナップ→(i,clamped)。それ以上離れていれば(None,t)
        for i,b in enumerate(blocks):
            if b["s0"]<=t<=b["s1"]: return i,t
        best=None;bd=1e9;bt=t
        for i,b in enumerate(blocks):
            if t<b["s0"]: d=b["s0"]-t; tt=b["s0"]
            else: d=t-b["s1"]; tt=b["s1"]
            if d<bd: bd=d;best=i;bt=tt
        return (best,bt) if bd<=TOL else (None,t)
    def mapf(t,bi):  # 元秒 → カット後フレーム（XMLと同一計算）。ブロック範囲にクランプ
        b=blocks[bi]; tt=min(max(t,b["s0"]),b["s1"])
        return b["ts"]+(f(tt,fps)-b["sin"])
    # 単語を短いテロップ行にまとめる（ブロック跨ぎ/字数超過/0.45秒以上の間/句読点で改行）
    lines=[]; cur=None
    for ws,we,wt in words:
        bi,wss=locate(ws)
        if bi is None: continue  # 本当にカット(無音)区間内の語のみ除外
        sf=mapf(wss,bi); ef=mapf(we,bi)
        if cur and (cur["bi"]!=bi or len(cur["txt"])+len(wt)>maxc or (sf-cur["ef"])>int(0.45*fps)):
            lines.append(cur); cur=None
        if cur is None:
            cur={"bi":bi,"sf":sf,"ef":max(ef,sf),"txt":wt}
        else:
            cur["txt"]+=wt; cur["ef"]=max(ef,cur["ef"])
        if re.search(r"[。．！？!?]$",wt):
            lines.append(cur); cur=None
    if cur: lines.append(cur)
    # [sf,ef,txt] へ整形 → 重なり回避
    rows=[]
    for L in lines:
        sf=L["sf"]; ef=L["ef"]
        if ef-sf<int(0.4*fps): ef=sf+int(0.7*fps)
        txt=collapse_inline(L["txt"].replace("。","").replace("、","").strip())
        for a_,b_ in SUBS.items(): txt=txt.replace(a_,b_)
        if txt: rows.append([sf,ef,txt])
    rows.sort(key=lambda x:x[0])
    # 隣接する完全同一テキスト行を1つに統合（whisper重複の残り）
    merged=[]
    for r in rows:
        if merged and r[2]==merged[-1][2]: merged[-1][1]=max(merged[-1][1],r[1])
        else: merged.append(r)
    rows=merged
    for i in range(1,len(rows)):
        if rows[i][0]<rows[i-1][1]: rows[i-1][1]=rows[i][0]  # 前行の末尾を詰める
    def tc(fr):
        t=fr/fps; h=int(t//3600); mm=int(t%3600//60); s=int(t%60); ms=int(round((t-int(t))*1000))
        return f"{h:02d}:{mm:02d}:{s:02d},{ms:03d}"
    o=[]; n=1
    for aa,bb,c in rows:
        if bb<=aa: continue
        o.append(f"{n}\n{tc(aa)} --> {tc(bb)}\n{c}\n"); n+=1
    return "\n".join(o), n-1

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True)
    ap.add_argument("--noise",default="-30dB"); ap.add_argument("--d",type=float,default=0.35)
    ap.add_argument("--pad",type=float,default=0.06); ap.add_argument("--minkeep",type=float,default=0.12)
    ap.add_argument("--maxchars",type=int,default=18); ap.add_argument("--model",default="small")
    ap.add_argument("--outdir",default=None); ap.add_argument("--no-telop",action="store_true")
    a=ap.parse_args()
    src=a.input
    if not os.path.exists(src): sys.exit("入力が見つかりません: "+src)
    outdir=a.outdir or os.path.dirname(src); base=os.path.splitext(os.path.basename(src))[0]
    fps=get_fps(src); w,h=get_dims(src); total=get_duration(src); total_frames=f(total,fps)
    print(f"fps={fps:.3f} {w}x{h} {total:.1f}s")
    sil=detect_silences(src,a.noise,a.d)
    blocks,run=build_blocks(sil,total,fps,a.pad,a.minkeep)
    print(f"無音{len(sil)}区間 → keep{len(blocks)}ブロック / カット後 {run/fps:.1f}秒 (除去 {(total_frames-run)/fps:.1f}秒)")
    xml=make_xml(src,blocks,run,w,h,total_frames)
    xmlpath=os.path.join(outdir,base+"_autocut.xml"); open(xmlpath,"w").write(xml)
    import xml.dom.minidom as M; M.parseString(xml)
    print("XML:",xmlpath)
    if not a.no_telop:
        words=transcribe_words(src,a.model)
        srt,nlines=make_srt(words,blocks,run,fps,a.maxchars)
        srtpath=os.path.join(outdir,base+"_telop.srt"); open(srtpath,"w").write(srt)
        print(f"SRT: {srtpath} (単語{len(words)}語 → テロップ{nlines}枚)")
    print("完了。Premiereで XML を読み込み→ カット済みシーケンス、SRTを読み込み→ テロップ。")

if __name__=="__main__": main()
