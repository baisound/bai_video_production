#!/usr/bin/env python3
"""Silence-cut reference worker and Premiere FCP7 XML/SRT adapter.

Corrected/adopted from the original ppro_autocut.py:
- exact rational frame-rate handling;
- VFR detection and fail-safe behaviour;
- checked ffmpeg/ffprobe execution;
- XML DOM construction instead of string replacement;
- external dictionary configuration;
- reusable timeline-map.json output;
- atomic output writes and structured reports.
"""
from __future__ import annotations

import argparse
import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Iterable, Sequence

from common import (
    FrameRate,
    atomic_write_json,
    atomic_write_text,
    load_json,
    parse_fraction,
    round_fraction,
    run_command,
    sha256_file,
)


@dataclass(frozen=True)
class MediaInfo:
    path: Path
    frame_rate: FrameRate
    r_frame_rate: Fraction
    avg_frame_rate: Fraction
    time_base: Fraction
    width: int
    height: int
    duration_us: int
    audio_channels: int
    audio_sample_rate: int
    is_vfr: bool


@dataclass(frozen=True)
class KeepBlock:
    block_id: str
    source_start_us: int
    source_end_us: int
    source_in_frame: int
    source_out_frame: int
    timeline_start_frame: int
    timeline_end_frame: int

    def contains(self, source_us: int) -> bool:
        return self.source_start_us <= source_us <= self.source_end_us


def probe_media(path: Path) -> MediaInfo:
    result = run_command(
        [
            "ffprobe",
            "-v",
            "error",
            "-print_format",
            "json",
            "-show_streams",
            "-show_format",
            str(path),
        ],
        timeout=120,
    )
    data = json.loads(result.stdout)
    video = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), None)
    if video is None:
        raise ValueError("No video stream found")
    audio = next((s for s in data.get("streams", []) if s.get("codec_type") == "audio"), {})

    r_rate = parse_fraction(video.get("r_frame_rate"))
    avg_rate = parse_fraction(video.get("avg_frame_rate"), fallback=r_rate)
    selected = avg_rate if avg_rate > 0 else r_rate
    frame_rate = FrameRate(selected.numerator, selected.denominator)
    time_base = parse_fraction(video.get("time_base"), fallback=Fraction(1, 1_000_000))
    duration_s = video.get("duration") or data.get("format", {}).get("duration")
    if duration_s is None:
        raise ValueError("Media duration is unavailable")
    duration_us = round(float(duration_s) * 1_000_000)
    rate_delta = abs(float(r_rate - avg_rate))
    is_vfr = rate_delta > max(0.001, float(avg_rate) * 0.0001)

    return MediaInfo(
        path=path,
        frame_rate=frame_rate,
        r_frame_rate=r_rate,
        avg_frame_rate=avg_rate,
        time_base=time_base,
        width=int(video["width"]),
        height=int(video["height"]),
        duration_us=duration_us,
        audio_channels=int(audio.get("channels", 2)),
        audio_sample_rate=int(audio.get("sample_rate", 48_000)),
        is_vfr=is_vfr,
    )


def detect_silences(path: Path, noise: str, duration: float, total_us: int) -> list[tuple[int, int]]:
    result = run_command(
        [
            "ffmpeg",
            "-hide_banner",
            "-nostats",
            "-vn",
            "-i",
            str(path),
            "-af",
            f"silencedetect=noise={noise}:d={duration}",
            "-f",
            "null",
            "-",
        ],
        timeout=3600,
    )
    silences: list[tuple[int, int]] = []
    open_start_us: int | None = None
    for line in result.stderr.splitlines():
        start_match = re.search(r"silence_start:\s*(-?[0-9.]+)", line)
        if start_match:
            open_start_us = max(0, round(float(start_match.group(1)) * 1_000_000))
        end_match = re.search(r"silence_end:\s*([0-9.]+)", line)
        if end_match and open_start_us is not None:
            end_us = min(total_us, round(float(end_match.group(1)) * 1_000_000))
            if end_us > open_start_us:
                silences.append((open_start_us, end_us))
            open_start_us = None
    if open_start_us is not None and open_start_us < total_us:
        silences.append((open_start_us, total_us))
    return merge_intervals(silences)


def merge_intervals(intervals: Iterable[tuple[int, int]]) -> list[tuple[int, int]]:
    ordered = sorted((max(0, a), max(0, b)) for a, b in intervals if b > a)
    merged: list[list[int]] = []
    for start, end in ordered:
        if not merged or start > merged[-1][1]:
            merged.append([start, end])
        else:
            merged[-1][1] = max(merged[-1][1], end)
    return [(start, end) for start, end in merged]


def build_keep_blocks(
    silences: Sequence[tuple[int, int]],
    media: MediaInfo,
    *,
    padding_us: int,
    minimum_keep_us: int,
) -> tuple[list[KeepBlock], int]:
    keeps: list[tuple[int, int]] = []
    cursor = 0
    for silence_start, silence_end in silences:
        keep_end = min(max(silence_start + padding_us, 0), media.duration_us)
        next_start = min(max(silence_end - padding_us, 0), media.duration_us)
        if keep_end > cursor:
            keeps.append((cursor, keep_end))
        cursor = max(cursor, next_start)
    if cursor < media.duration_us:
        keeps.append((cursor, media.duration_us))
    keeps = [(a, b) for a, b in keeps if b - a >= minimum_keep_us]

    blocks: list[KeepBlock] = []
    timeline_cursor = 0
    for index, (source_start_us, source_end_us) in enumerate(keeps, start=1):
        source_in = media.frame_rate.microseconds_to_frames(source_start_us)
        source_out = media.frame_rate.microseconds_to_frames(source_end_us)
        if source_out <= source_in:
            continue
        duration_frames = source_out - source_in
        blocks.append(
            KeepBlock(
                block_id=f"BLOCK-{index:05d}",
                source_start_us=source_start_us,
                source_end_us=source_end_us,
                source_in_frame=source_in,
                source_out_frame=source_out,
                timeline_start_frame=timeline_cursor,
                timeline_end_frame=timeline_cursor + duration_frames,
            )
        )
        timeline_cursor += duration_frames
    return blocks, timeline_cursor


def locate_source_time(
    source_us: int,
    blocks: Sequence[KeepBlock],
    *,
    tolerance_us: int = 300_000,
) -> tuple[KeepBlock | None, int]:
    for block in blocks:
        if block.contains(source_us):
            return block, source_us
    best_block: KeepBlock | None = None
    best_distance: int | None = None
    best_time = source_us
    for block in blocks:
        if source_us < block.source_start_us:
            distance = block.source_start_us - source_us
            snapped = block.source_start_us
        else:
            distance = source_us - block.source_end_us
            snapped = block.source_end_us
        if best_distance is None or distance < best_distance:
            best_block = block
            best_distance = distance
            best_time = snapped
    if best_distance is not None and best_distance <= tolerance_us:
        return best_block, best_time
    return None, source_us


def source_us_to_timeline_frame(source_us: int, block: KeepBlock, rate: FrameRate) -> int:
    clamped = min(max(source_us, block.source_start_us), block.source_end_us)
    relative_frames = rate.microseconds_to_frames(clamped) - block.source_in_frame
    return block.timeline_start_frame + relative_frames


def timeline_map_document(media: MediaInfo, blocks: Sequence[KeepBlock], run_frames: int) -> dict:
    return {
        "schema_name": "timeline-map",
        "schema_version": "2.0",
        "source_path": str(media.path),
        "source_sha256": sha256_file(media.path),
        "frame_rate": media.frame_rate.to_dict(),
        "source_duration_us": media.duration_us,
        "timeline_duration_frames": run_frames,
        "timeline_duration_us": media.frame_rate.frames_to_microseconds(run_frames),
        "blocks": [block.__dict__ for block in blocks],
    }


def add_text(parent: ET.Element, name: str, value: object) -> ET.Element:
    element = ET.SubElement(parent, name)
    element.text = str(value)
    return element


def add_rate(parent: ET.Element, rate: FrameRate) -> ET.Element:
    element = ET.SubElement(parent, "rate")
    add_text(element, "timebase", rate.timebase)
    add_text(element, "ntsc", "TRUE" if rate.ntsc else "FALSE")
    return element


def add_source_file(
    clip: ET.Element,
    *,
    file_id: str,
    media: MediaInfo,
    total_frames: int,
    include_metadata: bool,
) -> None:
    file_element = ET.SubElement(clip, "file", {"id": file_id})
    if not include_metadata:
        return
    add_text(file_element, "name", media.path.name)
    add_text(file_element, "pathurl", media.path.as_uri())
    add_rate(file_element, media.frame_rate)
    add_text(file_element, "duration", total_frames)
    media_element = ET.SubElement(file_element, "media")
    video = ET.SubElement(media_element, "video")
    sample = ET.SubElement(video, "samplecharacteristics")
    add_text(sample, "width", media.width)
    add_text(sample, "height", media.height)
    audio = ET.SubElement(media_element, "audio")
    add_text(audio, "channelcount", media.audio_channels)


def build_fcp7_xml(media: MediaInfo, blocks: Sequence[KeepBlock], run_frames: int, sequence_name: str) -> str:
    total_frames = media.frame_rate.microseconds_to_frames(media.duration_us)
    root = ET.Element("xmeml", {"version": "4"})
    sequence = ET.SubElement(root, "sequence", {"id": "seq1"})
    add_text(sequence, "name", sequence_name)
    add_text(sequence, "duration", run_frames)
    add_rate(sequence, media.frame_rate)
    media_element = ET.SubElement(sequence, "media")

    video_element = ET.SubElement(media_element, "video")
    video_format = ET.SubElement(video_element, "format")
    video_sample = ET.SubElement(video_format, "samplecharacteristics")
    add_rate(video_sample, media.frame_rate)
    add_text(video_sample, "width", media.width)
    add_text(video_sample, "height", media.height)
    video_track = ET.SubElement(video_element, "track")

    audio_element = ET.SubElement(media_element, "audio")
    audio_format = ET.SubElement(audio_element, "format")
    audio_sample = ET.SubElement(audio_format, "samplecharacteristics")
    add_text(audio_sample, "depth", 16)
    add_text(audio_sample, "samplerate", 48_000)
    audio_track = ET.SubElement(audio_element, "track")

    for index, block in enumerate(blocks):
        duration = block.timeline_end_frame - block.timeline_start_frame
        for prefix, track, media_type in (
            ("v", video_track, "video"),
            ("a", audio_track, "audio"),
        ):
            clip = ET.SubElement(track, "clipitem", {"id": f"{prefix}{index}"})
            add_text(clip, "name", media.path.name)
            add_text(clip, "duration", total_frames)
            add_rate(clip, media.frame_rate)
            add_text(clip, "start", block.timeline_start_frame)
            add_text(clip, "end", block.timeline_end_frame)
            add_text(clip, "in", block.source_in_frame)
            add_text(clip, "out", block.source_out_frame)
            add_source_file(
                clip,
                file_id="file1",
                media=media,
                total_frames=total_frames,
                include_metadata=(index == 0 and media_type == "video"),
            )
            source_track = ET.SubElement(clip, "sourcetrack")
            add_text(source_track, "mediatype", media_type)
            add_text(source_track, "trackindex", 1)

    ET.indent(root, space="  ")
    body = ET.tostring(root, encoding="unicode")
    return '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n' + body + "\n"


def load_replacements(path: str | None) -> dict[str, str]:
    if not path:
        return {}
    value = load_json(path)
    if isinstance(value, dict) and "replacements" in value:
        value = value["replacements"]
    if not isinstance(value, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in value.items()):
        raise ValueError("Dictionary JSON must be an object of string replacements")
    return value


def collapse_inline(text: str) -> str:
    # Optional defensive cleanup retained from the original implementation.
    length = len(text)
    for period in range(4, length // 2 + 1):
        if length % period == 0 and text == text[:period] * (length // period):
            return text[:period]
    return text


def parse_transcript_words(document: dict) -> list[tuple[int, int, str]]:
    words: list[tuple[int, int, str]] = []
    for segment in document.get("segments", []):
        segment_words = segment.get("words") or []
        for word in segment_words:
            text = word.get("text", word.get("w", ""))
            if "start_us" in word:
                start_us, end_us = int(word["start_us"]), int(word["end_us"])
            else:
                start_us = round(float(word["start"]) * 1_000_000)
                end_us = round(float(word["end"]) * 1_000_000)
            if str(text).strip():
                words.append((start_us, end_us, str(text).strip()))
        if not segment_words and str(segment.get("text", "")).strip():
            if "start_us" in segment:
                start_us, end_us = int(segment["start_us"]), int(segment["end_us"])
            else:
                start_us = round(float(segment["start"]) * 1_000_000)
                end_us = round(float(segment["end"]) * 1_000_000)
            words.append((start_us, end_us, str(segment["text"]).strip()))
    return words


def srt_timecode_from_frame(frame: int, rate: FrameRate) -> str:
    total_ms = round_fraction(rate.frames_to_seconds(frame) * 1000)
    hours, rem = divmod(total_ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, milliseconds = divmod(rem, 1000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{milliseconds:03d}"


def make_srt(
    words: Sequence[tuple[int, int, str]],
    blocks: Sequence[KeepBlock],
    run_frames: int,
    rate: FrameRate,
    *,
    max_chars: int,
    boundary_tolerance_us: int,
    replacements: dict[str, str],
) -> tuple[str, int]:
    lines: list[dict[str, object]] = []
    current: dict[str, object] | None = None
    gap_limit = rate.seconds_to_frames(Fraction(45, 100))

    for word_start_us, word_end_us, word_text in words:
        block, adjusted_start_us = locate_source_time(
            word_start_us,
            blocks,
            tolerance_us=boundary_tolerance_us,
        )
        if block is None:
            continue
        start_frame = source_us_to_timeline_frame(adjusted_start_us, block, rate)
        end_frame = source_us_to_timeline_frame(word_end_us, block, rate)
        if current and (
            current["block_id"] != block.block_id
            or len(str(current["text"])) + len(word_text) > max_chars
            or start_frame - int(current["end_frame"]) > gap_limit
        ):
            lines.append(current)
            current = None
        if current is None:
            current = {
                "block_id": block.block_id,
                "start_frame": start_frame,
                "end_frame": max(end_frame, start_frame),
                "text": word_text,
            }
        else:
            current["text"] = str(current["text"]) + word_text
            current["end_frame"] = max(end_frame, int(current["end_frame"]))
        if re.search(r"[。．！？!?]$", word_text):
            lines.append(current)
            current = None
    if current:
        lines.append(current)

    rows: list[list[object]] = []
    minimum = rate.seconds_to_frames(Fraction(2, 5))
    fallback = rate.seconds_to_frames(Fraction(7, 10))
    for line in lines:
        start = int(line["start_frame"])
        end = int(line["end_frame"])
        if end - start < minimum:
            end = min(run_frames, start + fallback)
        text = collapse_inline(str(line["text"]).replace("。", "").replace("、", "").strip())
        for before, after in replacements.items():
            text = text.replace(before, after)
        if text:
            rows.append([start, end, text])

    rows.sort(key=lambda row: int(row[0]))
    merged: list[list[object]] = []
    for row in rows:
        if merged and row[2] == merged[-1][2]:
            merged[-1][1] = max(int(merged[-1][1]), int(row[1]))
        else:
            merged.append(row)
    for index in range(1, len(merged)):
        if int(merged[index][0]) < int(merged[index - 1][1]):
            merged[index - 1][1] = merged[index][0]

    output: list[str] = []
    sequence = 1
    for start, end, text in merged:
        if int(end) <= int(start):
            continue
        output.append(
            f"{sequence}\n{srt_timecode_from_frame(int(start), rate)} --> "
            f"{srt_timecode_from_frame(int(end), rate)}\n{text}\n"
        )
        sequence += 1
    return "\n".join(output), sequence - 1


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--noise", default="-30dB")
    parser.add_argument("--silence-duration", "--d", type=float, default=0.35)
    parser.add_argument("--padding", "--pad", type=float, default=0.06)
    parser.add_argument("--minimum-keep", "--minkeep", type=float, default=0.12)
    parser.add_argument("--max-chars", "--maxchars", type=int, default=18)
    parser.add_argument("--outdir", default=None)
    parser.add_argument("--no-subtitles", "--no-telop", action="store_true")
    parser.add_argument("--transcript-json", default=None)
    parser.add_argument("--dictionary-json", default=None)
    parser.add_argument("--allow-vfr", action="store_true")
    parser.add_argument("--sequence-name", default="AI_AutoCut")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = Path(args.input).expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"Input not found: {source}")
    output_dir = Path(args.outdir).expanduser().resolve() if args.outdir else source.parent
    output_dir.mkdir(parents=True, exist_ok=True)
    base = source.stem

    media = probe_media(source)
    if media.is_vfr and not args.allow_vfr:
        raise SystemExit(
            "Variable-frame-rate media detected. Normalize it with the approved CFR profile before XML generation, "
            "or use --allow-vfr only for an explicit compatibility test."
        )

    silences = detect_silences(source, args.noise, args.silence_duration, media.duration_us)
    blocks, run_frames = build_keep_blocks(
        silences,
        media,
        padding_us=round(args.padding * 1_000_000),
        minimum_keep_us=round(args.minimum_keep * 1_000_000),
    )
    if not blocks:
        raise SystemExit("No keep blocks remain after silence detection")

    xml = build_fcp7_xml(media, blocks, run_frames, args.sequence_name)
    xml_path = output_dir / f"{base}_autocut.xml"
    ET.fromstring(xml.split("<!DOCTYPE xmeml>\n", 1)[1])
    atomic_write_text(xml_path, xml)

    map_path = output_dir / f"{base}_timeline-map.json"
    atomic_write_json(map_path, timeline_map_document(media, blocks, run_frames))

    subtitle_path: Path | None = None
    subtitle_count = 0
    if not args.no_subtitles and args.transcript_json:
        transcript = load_json(args.transcript_json)
        if not isinstance(transcript, dict):
            raise ValueError("Transcript JSON must be an object")
        words = parse_transcript_words(transcript)
        replacements = load_replacements(args.dictionary_json)
        srt, subtitle_count = make_srt(
            words,
            blocks,
            run_frames,
            media.frame_rate,
            max_chars=args.max_chars,
            boundary_tolerance_us=300_000,
            replacements=replacements,
        )
        subtitle_path = output_dir / f"{base}_telop.srt"
        atomic_write_text(subtitle_path, srt)

    report = {
        "schema_name": "autocut-report",
        "schema_version": "2.0",
        "source": str(source),
        "frame_rate": media.frame_rate.to_dict(),
        "vfr_detected": media.is_vfr,
        "silence_count": len(silences),
        "keep_block_count": len(blocks),
        "timeline_duration_frames": run_frames,
        "xml": str(xml_path),
        "timeline_map": str(map_path),
        "subtitle": str(subtitle_path) if subtitle_path else None,
        "subtitle_count": subtitle_count,
    }
    atomic_write_json(output_dir / f"{base}_autocut-report.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
