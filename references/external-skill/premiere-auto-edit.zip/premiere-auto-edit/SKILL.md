---
name: premiere-auto-edit
description: 動画素材から「無音カット＋テロップ＋効果音(SE)＋BGM」を自動で入れたPremiere用タイムライン(FCP7 XML)を生成するスキル。ユーザーが動画素材を渡して「編集して」「カット・テロップ・SEを自動で入れて」「動画を仕上げて」等と言ったら使う。初回起動時はまず①使うSEを入れたフォルダ、②BGMファイル、の場所をヒアリングして設定を保存する。以後は素材パスを渡すだけで、カット→テロップ→SE→BGMを自動挿入したXMLとテロップSRTを出力する。ffmpeg / python3 / faster-whisper / Premiere(XMLインポート)で動作。
---

# Premiere 自動編集スキル（カット＋テロップ＋SE＋BGM）

素材動画を渡すと、**無音カット・テロップ(字幕)・効果音(SE)・BGM** を自動で入れた
Premiere用タイムライン(FCP7 XML)と、テロップ(SRT)を生成する。Premiereで読み込むだけで
「ほぼ完成のラフ」が出来上がる。CEP/UXP/APIに依存せず **XMLインポート方式** なので確実。

このスキルの本体スクリプトは、このSKILL.mdと同じ場所の `scripts/` にある：
- `scripts/transcribe.py` … 文字起こし（元時刻つきJSON）
- `scripts/edit_pipeline.py` … 無音カット＋テロップ＋SE＋BGM を1本のXMLに統合
- `scripts/ppro_autocut.py` … カット/テロップの土台（edit_pipelineが内部で使用）
以降、これらを `<SKILL>/scripts/xxx.py` と表記する（`<SKILL>` はこのスキルのフォルダ）。

## 依存（最初に1回だけ確認）
`ffmpeg`・`python3`・`faster-whisper` が必要。無ければ案内する：
```
ffmpeg -version            # 無ければ: brew install ffmpeg
python3 -c "import faster_whisper"   # 無ければ: pip3 install faster-whisper
```

---

## 進め方（この順番で会話する）

### STEP 0｜初期設定（`<SKILL>/config.json` が無ければ必ず実施）
`<SKILL>/config.json` を読む。無い／不完全なら、以下を**1つずつ**ヒアリングする。

1. **SEフォルダ**を尋ねる：
   > 「使う効果音（SE）を1つのフォルダにまとめて、そのフォルダのパスを教えてください。
   >  ファイル名で用途が分かると精度が上がります（例：『場面転換.mp3』『キメ_キンッ.mp3』『拍手.mp3』）。」
   - 受け取ったら `find "<SEフォルダ>" -type f \( -iname "*.mp3" -o -iname "*.wav" -o -iname "*.m4a" -o -iname "*.aif" -o -iname "*.aiff" \)` で一覧を取得し、**何個あるか・どんな用途のSEが揃っているか**を要約して確認する。
2. **BGM**を尋ねる：
   > 「動画に敷くBGMファイルのパスを教えてください（1曲でOK。尺はこちらで自動調整します）。」
3. 設定を `<SKILL>/config.json` に保存する：
   ```json
   {"se_dir": "<SEフォルダ>", "bgm_path": "<BGMファイル>", "bgm_gain": "0.18"}
   ```
   - `bgm_gain` は線形音量（0.18 ≒ -15dB 目安）。「BGMが大きい/小さい」と言われたら数値を調整（小さく=0.10、大きめ=0.28 等）。

### STEP 1｜素材のヒアリング
> 「編集したい動画素材のパスを教えてください（フォルダでなくファイル）。」
- 受け取ったらファイルの存在を確認。出力は既定で**素材と同じフォルダ**に置かれる。

### STEP 2｜文字起こし（SE判断とテロップの材料）
```
python3 "<SKILL>/scripts/transcribe.py" --input "<素材>" --model small
```
- `<素材>_transcript.json`（元時刻つきセグメント）が出る。中身を読む。
- 急いでいなければ `--model large-v3`（精度↑/遅い）。標準は `small`。

### STEP 3｜SE配置の判断（ここがAIの仕事）
transcript.json の内容を読み、**節目を見つけて、STEP0のSEフォルダに実在するファイルから**最適なSEを割り当てる。
配置プランを `se_plan.json` として **SEの絶対パス** で書き出す：
```json
[
 {"t": 4.10,  "label": "挨拶・登場",   "se": "/abs/path/登場.mp3"},
 {"t": 17.0,  "label": "ポイント提示", "se": "/abs/path/キーン.mp3"}
]
```
- `t` は **元動画の秒**（transcript.json の start を使う。カット後への変換はスクリプトが行う）。
- SE割り当ての目安（フォルダのファイル名と内容から最も近いものを選ぶ。無いカテゴリは飛ばす）：
  | 節目 | 選ぶSEの例 |
  |---|---|
  | 冒頭の挨拶・登場 | 登場/パーン/ジャーン系 |
  | タイトル・本題提示 | シャキーン/イントロ系 |
  | 要点・数字の強調（「○つ」「1500人」「5万円」等） | キーン/ポイント系 |
  | 話題の切り替え・章/トピックの開始（「1つ目」「次に」「まとめると」） | 場面転換/ビュン系 |
  | 見出し・キメのひと言 | キメ/キンッ系 |
  | 箇条書きの各項目（「1 …」「2 …」） | ピコン/ピッ系（各項目に） |
  | 自虐・ボケ・失敗談 | トホホ/ズッコケ系 |
  | 締め・感謝・エンディング | 拍手/万能系 |
- 密度の目安：**15〜25秒に1回**程度（多すぎ注意）。SE時刻はスクリプト側で**テロップが出る瞬間に自動スナップ**される。
- 固有名詞の誤認識（人名など）は edit_pipeline が拾ったテロップに残るので、頻出する誤変換は `scripts/ppro_autocut.py` の `SUBS={}` に追記して直す。

### STEP 4｜自動編集を実行
config.json の値を使って実行：
```
python3 "<SKILL>/scripts/edit_pipeline.py" \
  --input "<素材>" \
  --se-plan "<se_plan.jsonのパス>" \
  --words-json "<素材>_transcript.json" \
  --bgm "<config.bgm_path>" --bgm-gain "<config.bgm_gain>"
```
- 出力：`<素材>_edit.xml`（V1=カット映像 / A1=音声 / A2=SE / A3=BGM）と `<素材>_telop.srt`。
- `--words-json` で文字起こしを使い回すので追加の待ち時間なし。
- 微調整して作り直すときは se_plan を直して再実行（`--reuse-telop` でも可）。
- 無音カットの感度を変えたい時：`--noise -30dB`（小さい音まで切るなら -35dB）、`--d 0.35`（無音とみなす秒）。

### STEP 5｜Premiereで取り込み（ユーザーに案内）
1. Premiere で **ファイル→読み込み→ `<素材>_edit.xml`** を開く → 「AI_Edit」シーケンスが生成（V1/A1/A2/A3）。
2. 続けて **`<素材>_telop.srt` を読み込み** → プロジェクトのキャプション項目をタイムライン上部にドラッグ →
   「新しいキャプショントラック」ダイアログで **形式=サブタイトル / 開始点=ソースタイムコード** で OK。
3. これで C1=テロップ / V1=カット映像 / A1=音声 / A2=SE / A3=BGM が揃う。仕上げの微調整だけ手動で。

---

## 注意・コツ
- 出力XMLのfpsは素材に追従（NTSC 29.97等も自動）。Premiereの新規シーケンスはXMLが作るので素材と一致する。
- SEフォルダ/BGMを変えたい時は `<SKILL>/config.json` を編集するか「SE（BGM）を変えたい」と言ってもらう。
- 言い直し（リテイク）カットは未対応（無音カットのみ）。切りすぎ防止のため意図的にそうしている。
- 第三者に渡す場合：このスキルフォルダ一式（SKILL.md + scripts/）を `~/.claude/skills/premiere-auto-edit/` に置けば動く。依存（ffmpeg / faster-whisper）の導入だけ案内する。`config.json` は各自の初回設定で作られる。
