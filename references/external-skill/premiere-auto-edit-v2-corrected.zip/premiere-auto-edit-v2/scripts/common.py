#!/usr/bin/env python3
"""Shared helpers for the Premiere auto-edit reference implementation."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Iterable, Sequence


class ExternalCommandError(RuntimeError):
    """Raised when ffmpeg/ffprobe or another external command fails."""

    def __init__(self, command: Sequence[str], returncode: int, stderr: str):
        self.command = list(command)
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(
            f"Command failed ({returncode}): {' '.join(command)}\n{stderr[-4000:]}"
        )


def run_command(
    command: Sequence[str],
    *,
    timeout: float = 3600,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Run a command without a shell and capture evidence-friendly output."""
    result = subprocess.run(
        list(command),
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if check and result.returncode != 0:
        raise ExternalCommandError(command, result.returncode, result.stderr)
    return result


def parse_fraction(value: str | None, *, fallback: Fraction | None = None) -> Fraction:
    if not value or value in {"0/0", "N/A"}:
        if fallback is None:
            raise ValueError(f"Invalid rational value: {value!r}")
        return fallback
    if "/" in value:
        numerator, denominator = value.split("/", 1)
        denominator_i = int(denominator)
        if denominator_i == 0:
            if fallback is None:
                raise ValueError(f"Invalid rational value: {value!r}")
            return fallback
        return Fraction(int(numerator), denominator_i)
    return Fraction(value)


def round_fraction(value: Fraction) -> int:
    """Round a non-negative Fraction to nearest integer, half up."""
    if value < 0:
        return -round_fraction(-value)
    return (2 * value.numerator + value.denominator) // (2 * value.denominator)


@dataclass(frozen=True)
class FrameRate:
    numerator: int
    denominator: int

    @property
    def fraction(self) -> Fraction:
        return Fraction(self.numerator, self.denominator)

    @property
    def float_value(self) -> float:
        return float(self.fraction)

    @property
    def timebase(self) -> int:
        # FCP7 XML expresses NTSC rates as 24/30/60 + ntsc TRUE.
        known = {
            Fraction(24000, 1001): 24,
            Fraction(30000, 1001): 30,
            Fraction(60000, 1001): 60,
        }
        return known.get(self.fraction, round_fraction(self.fraction))

    @property
    def ntsc(self) -> bool:
        return self.fraction in {
            Fraction(24000, 1001),
            Fraction(30000, 1001),
            Fraction(60000, 1001),
        }

    def seconds_to_frames(self, seconds: float | Fraction) -> int:
        sec = seconds if isinstance(seconds, Fraction) else Fraction(str(seconds))
        return round_fraction(sec * self.fraction)

    def microseconds_to_frames(self, microseconds: int) -> int:
        return round_fraction(Fraction(microseconds, 1_000_000) * self.fraction)

    def frames_to_microseconds(self, frames: int) -> int:
        return round_fraction(Fraction(frames, 1) / self.fraction * 1_000_000)

    def frames_to_seconds(self, frames: int) -> Fraction:
        return Fraction(frames, 1) / self.fraction

    def to_dict(self) -> dict[str, int | float | bool]:
        return {
            "fps_num": self.numerator,
            "fps_den": self.denominator,
            "fps": self.float_value,
            "timebase": self.timebase,
            "ntsc": self.ntsc,
        }


def sha256_file(path: str | os.PathLike[str], chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write_text(path: str | os.PathLike[str], text: str, encoding: str = "utf-8") -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(text, encoding=encoding)
    os.replace(temporary, target)


def atomic_write_json(path: str | os.PathLike[str], value: object) -> None:
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def load_json(path: str | os.PathLike[str]) -> object:
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)
