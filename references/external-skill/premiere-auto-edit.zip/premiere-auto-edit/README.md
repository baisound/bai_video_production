# premiere-auto-edit（配布用 README）

動画素材を渡すだけで **無音カット＋テロップ＋効果音(SE)＋BGM** を自動で入れた
Premiere用タイムライン(XML)を作るスキル。Claude Code で動く。

## インストール（受け取った人の作業）
1. このフォルダ一式を `~/.claude/skills/premiere-auto-edit/` に置く。
   ```
   ~/.claude/skills/premiere-auto-edit/
   ├── SKILL.md
   ├── README.md
   ├── scripts/transcribe.py
   ├── scripts/edit_pipeline.py
   └── scripts/ppro_autocut.py
   ```
2. 依存ツールを入れる（初回のみ）：
   ```
   brew install ffmpeg
   pip3 install faster-whisper
   ```
3. Claude Code を開いて「`/premiere-auto-edit`」または「動画を編集して」と話しかける。

## 使い方
1. 初回だけ、Claudeが2つ聞いてくる：
   - **使うSEを入れたフォルダ**のパス（効果音をまとめておく。ファイル名で用途が分かると精度UP）
   - **BGMファイル**のパス（1曲でOK）
   → `config.json` に保存され、次回から聞かれない。
2. **編集したい動画のパス**を渡す。
3. 自動で「カット→テロップ→SE→BGM」を入れた `<素材>_edit.xml` と `<素材>_telop.srt` が出力される。
4. Premiereで：
   - `ファイル→読み込み→ _edit.xml`（V1カット映像 / A1音声 / A2 SE / A3 BGM）
   - `_telop.srt` を読み込み→タイムライン上部へドラッグ→形式=サブタイトル/開始点=ソースタイムコードでOK（C1テロップ）
5. 仕上げの微調整だけ手動で。

## よくある調整
- 「BGMが大きい/小さい」→ `config.json` の `bgm_gain`（0.18が標準。0.10で小さめ、0.28で大きめ）
- 「カットが浅い/深い」→ Claudeに「無音カットを強めに」と言う（内部で `--noise -35dB` 等）
- 人名などの誤字が毎回出る → `scripts/ppro_autocut.py` の `SUBS={}` に `"誤":"正"` を追記
- SE/BGMを変えたい → 「SEフォルダ（BGM）を変えたい」と言う（config.jsonを更新）

## 仕組み（中身）
faster-whisperで文字起こし → ffmpegで無音区間検出してカット → Claudeが文字起こしを読んで
節目にSEを割り当て（テロップが出る瞬間にスナップ）→ FCP7 XML(xmeml)を生成。
CEP/UXP/API不要、XMLインポートのみなので環境に依存せず確実。
