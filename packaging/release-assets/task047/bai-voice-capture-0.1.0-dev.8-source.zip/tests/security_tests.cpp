#include "bai_obs_capture/capture_protocol.hpp"
#include "bai_obs_capture/ipc_client.hpp"

#include <algorithm>
#include <iostream>
#include <memory>
#include <string>

bool run_security_tests() {
  using namespace bai::obs_capture;
  SessionKey key{};
  const std::string valid(64, 'a');
  if (!parse_session_key_hex(valid, key)) return false;
  if (std::all_of(key.begin(), key.end(), [](std::uint8_t value) { return value == 0; })) return false;
  if (parse_session_key_hex(std::string(63, 'a'), key)) return false;
  if (parse_session_key_hex(std::string(64, 'z'), key)) return false;
  if (!std::all_of(key.begin(), key.end(), [](std::uint8_t value) { return value == 0; })) return false;

  auto core = std::make_unique<CaptureCore>();
  IpcClient client(*core, key);
  if (client.start()) return false;
  if (client.running()) return false;
  if (core->authorized()) return false;
  if (sizeof(WireHeader) != 88) return false;
  if (kPipeName[0] != L'\\' || kQueueCapacity != 64 || kMaxFramesPerCallback != 8192) return false;
  std::cout << "security_tests=PASS\n";
  return true;
}
