#include "bai_obs_capture/ipc_client.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstring>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <bcrypt.h>
#endif

namespace bai::obs_capture {
namespace {

std::uint8_t decode_hex(char value, bool &valid) noexcept {
  if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
  if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
  if (value >= 'A' && value <= 'F') return static_cast<std::uint8_t>(value - 'A' + 10);
  valid = false;
  return 0;
}

#ifdef _WIN32
bool write_exact(HANDLE pipe, const void *data, std::uint32_t bytes) noexcept {
  const auto *cursor = static_cast<const std::uint8_t *>(data);
  std::uint32_t remaining = bytes;
  while (remaining > 0) {
    DWORD written = 0;
    if (!WriteFile(pipe, cursor, remaining, &written, nullptr) || written == 0) return false;
    cursor += written;
    remaining -= written;
  }
  return true;
}

bool compute_hmac(const SessionKey &key, const WireHeader &header, const AudioFrame &frame,
                  std::array<std::uint8_t, kMacBytes> &out) noexcept {
  BCRYPT_ALG_HANDLE algorithm = nullptr;
  BCRYPT_HASH_HANDLE hash = nullptr;
  DWORD object_bytes = 0;
  DWORD returned = 0;
  std::array<std::uint8_t, 512> object{};
  bool ok = false;

  if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr,
                                  BCRYPT_ALG_HANDLE_HMAC_FLAG) < 0)
    goto cleanup;
  if (BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH,
                        reinterpret_cast<PUCHAR>(&object_bytes), sizeof(object_bytes),
                        &returned, 0) < 0 || object_bytes > object.size())
    goto cleanup;
  if (BCryptCreateHash(algorithm, &hash, object.data(), object_bytes,
                       const_cast<PUCHAR>(key.data()), static_cast<ULONG>(key.size()), 0) < 0)
    goto cleanup;

  if (BCryptHashData(hash, reinterpret_cast<PUCHAR>(const_cast<WireHeader *>(&header)),
                     static_cast<ULONG>(offsetof(WireHeader, hmac_sha256)), 0) < 0)
    goto cleanup;
  if (BCryptHashData(hash, reinterpret_cast<PUCHAR>(const_cast<float *>(frame.samples.data())),
                     header.payload_bytes, 0) < 0)
    goto cleanup;
  if (BCryptFinishHash(hash, out.data(), static_cast<ULONG>(out.size()), 0) < 0) goto cleanup;
  ok = true;

cleanup:
  if (hash != nullptr) BCryptDestroyHash(hash);
  if (algorithm != nullptr) BCryptCloseAlgorithmProvider(algorithm, 0);
  std::fill(object.begin(), object.end(), std::uint8_t{0});
  return ok;
}
#endif

}  // namespace

bool parse_session_key_hex(std::string_view text, SessionKey &out) noexcept {
  out.fill(0);
  if (text.size() != out.size() * 2U) return false;
  bool valid = true;
  for (std::size_t i = 0; i < out.size(); ++i) {
    const auto high = decode_hex(text[i * 2U], valid);
    const auto low = decode_hex(text[i * 2U + 1U], valid);
    out[i] = static_cast<std::uint8_t>((high << 4U) | low);
  }
  if (!valid) out.fill(0);
  return valid;
}

IpcClient::IpcClient(CaptureCore &core, const SessionKey &key) noexcept : core_(core), key_(key) {}

IpcClient::~IpcClient() {
  stop();
  std::fill(key_.begin(), key_.end(), std::uint8_t{0});
  std::fill(nonce_.begin(), nonce_.end(), std::uint8_t{0});
}

bool IpcClient::start() {
  bool expected = false;
  if (!running_.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) return false;
  if (std::all_of(key_.begin(), key_.end(), [](std::uint8_t value) { return value == 0; })) {
    running_.store(false, std::memory_order_release);
    return false;
  }
#ifdef _WIN32
  if (BCryptGenRandom(nullptr, nonce_.data(), static_cast<ULONG>(nonce_.size()),
                      BCRYPT_USE_SYSTEM_PREFERRED_RNG) < 0) {
    running_.store(false, std::memory_order_release);
    return false;
  }
#else
  running_.store(false, std::memory_order_release);
  return false;
#endif
  stop_requested_.store(false, std::memory_order_release);
  worker_ = std::thread(&IpcClient::worker_main, this);
  return true;
}

void IpcClient::stop() noexcept {
  stop_requested_.store(true, std::memory_order_release);
  if (worker_.joinable()) worker_.join();
  running_.store(false, std::memory_order_release);
}

bool IpcClient::running() const noexcept { return running_.load(std::memory_order_acquire); }

std::uint64_t IpcClient::sent_frames() const noexcept {
  return sent_frames_.load(std::memory_order_relaxed);
}

std::uint64_t IpcClient::transport_drops() const noexcept {
  return transport_drops_.load(std::memory_order_relaxed);
}

void IpcClient::worker_main() noexcept {
#ifdef _WIN32
  HANDLE pipe = INVALID_HANDLE_VALUE;
  std::uint64_t sequence = 0;
  AudioFrame frame{};
  core_.set_authorized(false);

  while (!stop_requested_.load(std::memory_order_acquire)) {
    if (pipe == INVALID_HANDLE_VALUE) {
      pipe = CreateFileW(kPipeName, GENERIC_WRITE, 0, nullptr, OPEN_EXISTING,
                         FILE_ATTRIBUTE_NORMAL, nullptr);
      if (pipe == INVALID_HANDLE_VALUE) {
        core_.set_authorized(false);
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        continue;
      }
      // This client opens the pipe with GENERIC_WRITE only. Setting a read mode
      // on a write-only handle makes SetNamedPipeHandleState fail before the
      // first audio frame can be sent. Non-blocking write mode is sufficient.
      DWORD mode = PIPE_NOWAIT;
      if (!SetNamedPipeHandleState(pipe, &mode, nullptr, nullptr)) {
        core_.set_authorized(false);
        CloseHandle(pipe);
        pipe = INVALID_HANDLE_VALUE;
        continue;
      }
      // Copy audio only while a receiver owns this authenticated session.
      // Disconnecting the receiver returns the callback to its bounded fast path.
      core_.set_authorized(true);
    }

    if (!core_.try_pop(frame)) {
      std::this_thread::sleep_for(std::chrono::milliseconds(2));
      continue;
    }

    WireHeader header{};
    header.header_bytes = static_cast<std::uint16_t>(sizeof(header));
    header.sequence = sequence++;
    header.timestamp_ns = frame.timestamp_ns;
    header.frames = frame.frames;
    header.planes = frame.planes;
    header.sample_count = frame.sample_count;
    header.payload_bytes = frame.sample_count * static_cast<std::uint32_t>(sizeof(float));
    header.session_nonce = nonce_;

    if (!compute_hmac(key_, header, frame, header.hmac_sha256) ||
        !write_exact(pipe, &header, static_cast<std::uint32_t>(sizeof(header))) ||
        !write_exact(pipe, frame.samples.data(), header.payload_bytes)) {
      transport_drops_.fetch_add(1, std::memory_order_relaxed);
      core_.set_authorized(false);
      CloseHandle(pipe);
      pipe = INVALID_HANDLE_VALUE;
      continue;
    }
    sent_frames_.fetch_add(1, std::memory_order_relaxed);
  }
  core_.set_authorized(false);
  if (pipe != INVALID_HANDLE_VALUE) CloseHandle(pipe);
#endif
  running_.store(false, std::memory_order_release);
}

}  // namespace bai::obs_capture
