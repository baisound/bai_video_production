#!/usr/bin/env python3
"""
transcribe.py — 動画/音声を文字起こしし、元時刻つきセグメントJSONを出力。
  SE配置の判断材料（節目の時刻）に使う。VAD無効で時刻ズレを防ぐ。
  使い方: python3 transcribe.py --input <movie> [--model small|large-v3] [--out transcript.json]
  出力JSON: {"duration":秒, "segments":[{"start","end","text","words":[{"w","start","end"}]}]}
"""
import argparse, json, os
from faster_whisper import WhisperModel

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True)
    ap.add_argument("--model",default="small")          # 速度優先=small / 精度優先=large-v3
    ap.add_argument("--out",default=None)
    a=ap.parse_args()
    src=a.input
    out=a.out or os.path.join(os.path.dirname(os.path.abspath(src)),
                              os.path.splitext(os.path.basename(src))[0]+"_transcript.json")
    m=WhisperModel(a.model,device="cpu",compute_type="int8")
    segs,info=m.transcribe(src,language="ja",vad_filter=False,word_timestamps=True,
                           condition_on_previous_text=False)
    data=[]
    for s in segs:
        words=[{"w":w.word,"start":round(w.start,3),"end":round(w.end,3)} for w in (s.words or [])]
        data.append({"start":round(s.start,3),"end":round(s.end,3),"text":s.text.strip(),"words":words})
        print(f"[{s.start:6.2f}-{s.end:6.2f}] {s.text.strip()}",flush=True)
    json.dump({"duration":info.duration,"segments":data},open(out,"w",encoding="utf-8"),
              ensure_ascii=False,indent=1)
    print(f"\nDONE {len(data)} segments -> {out}",flush=True)

if __name__=="__main__": main()
