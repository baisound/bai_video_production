#!/usr/bin/env python3
"""Integrated Premiere FCP7 XML rough-edit pipeline.

Corrected/adopted from the original edit_pipeline.py.  AI/LLM judgement is
provided as an external SE placement plan; this module performs deterministic
validation, time mapping, subtitle snapping, preview BGM generation and XML
assembly.
"""
from __future__ import annotations

import argparse
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Sequence

import ppro_autocut as P
from common import atomic_write_json, atomic_write_text, load_json, run_command


def media_duration_us(path: Path) -> int:
    result = run_command(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        timeout=120,
    )
    return round(float(result.stdout.strip()) * 1_000_000)


def parse_srt_start_frames(srt_text: str, rate: P.FrameRate) -> list[int]:
    import re

    starts: list[int] = []
    for match in re.finditer(r"(\d\d):(\d\d):(\d\d),(\d\d\d)\s*-->", srt_text):
        hours, minutes, seconds, milliseconds = map(int, match.groups())
        total_us = (
            hours * 3_600_000_000
            + minutes * 60_000_000
            + seconds * 1_000_000
            + milliseconds * 1000
        )
        starts.append(rate.microseconds_to_frames(total_us))
    return sorted(set(starts))


def load_se_plan(path: Path) -> list[dict]:
    value = load_json(path)
    if isinstance(value, dict):
        placements = value.get("placements", [])
    elif isinstance(value, list):
        placements = value
    else:
        raise ValueError("SE plan must be an array or an object containing placements")
    if not isinstance(placements, list):
        raise ValueError("SE placements must be an array")
    return [item for item in placements if isinstance(item, dict)]


def placement_source_us(item: dict) -> int:
    if "source_time_us" in item:
        return int(item["source_time_us"])
    if "t" in item:
        return round(float(item["t"]) * 1_000_000)
    raise ValueError("SE placement requires source_time_us or t")


def placement_path(item: dict, root: Path | None) -> Path:
    raw = item.get("file_path") or item.get("se")
    if not raw:
        raise ValueError("SE placement requires file_path or se")
    path = Path(str(raw)).expanduser()
    if not path.is_absolute():
        if root is None:
            raise ValueError(f"Relative SE path has no --se-root: {path}")
        path = root / path
    return path.resolve()


def nearest_with_tolerance(value: int, candidates: Sequence[int], tolerance: int) -> tuple[int, bool]:
    if not candidates:
        return value, False
    nearest = min(candidates, key=lambda candidate: abs(candidate - value))
    if abs(nearest - value) <= tolerance:
        return nearest, nearest != value
    return value, False


def add_rate(parent: ET.Element, rate: P.FrameRate) -> None:
    P.add_rate(parent, rate)


def build_se_track(
    placements: Sequence[dict],
    blocks: Sequence[P.KeepBlock],
    rate: P.FrameRate,
    *,
    subtitle_starts: Sequence[int],
    snap_tolerance_ms: int,
    se_root: Path | None,
) -> tuple[ET.Element, list[dict], list[dict]]:
    track = ET.Element("track")
    placed: list[dict] = []
    dropped: list[dict] = []
    snap_tolerance_frames = rate.microseconds_to_frames(snap_tolerance_ms * 1000)

    for index, item in enumerate(placements):
        label = str(item.get("label") or item.get("purpose") or f"SE-{index + 1}")
        try:
            source_us = placement_source_us(item)
            path = placement_path(item, se_root)
        except (ValueError, TypeError) as exc:
            dropped.append({"label": label, "reason": str(exc)})
            continue
        if not path.is_file():
            dropped.append({"label": label, "reason": "FILE_NOT_FOUND", "path": str(path)})
            continue
        block, adjusted_us = P.locate_source_time(source_us, blocks, tolerance_us=300_000)
        if block is None:
            dropped.append({"label": label, "reason": "REMOVED_SOURCE_INTERVAL"})
            continue
        start_frame = P.source_us_to_timeline_frame(adjusted_us, block, rate)
        snap_policy = str(item.get("snap_policy", "CAPTION_OR_EVENT"))
        snapped = False
        if snap_policy in {"CAPTION", "CAPTION_OR_EVENT"}:
            per_item_ms = int(item.get("snap_tolerance_ms", snap_tolerance_ms))
            start_frame, snapped = nearest_with_tolerance(
                start_frame,
                subtitle_starts,
                rate.microseconds_to_frames(per_item_ms * 1000),
            )
        duration_frames = max(1, rate.microseconds_to_frames(media_duration_us(path)))
        end_frame = start_frame + duration_frames

        clip = ET.SubElement(track, "clipitem", {"id": f"se{index}"})
        P.add_text(clip, "name", path.name)
        P.add_text(clip, "enabled", "TRUE")
        P.add_text(clip, "duration", duration_frames)
        add_rate(clip, rate)
        P.add_text(clip, "start", start_frame)
        P.add_text(clip, "end", end_frame)
        P.add_text(clip, "in", 0)
        P.add_text(clip, "out", duration_frames)
        file_element = ET.SubElement(clip, "file", {"id": f"sefile{index}"})
        P.add_text(file_element, "name", path.name)
        P.add_text(file_element, "pathurl", path.as_uri())
        add_rate(file_element, rate)
        P.add_text(file_element, "duration", duration_frames)
        media = ET.SubElement(file_element, "media")
        audio = ET.SubElement(media, "audio")
        sample = ET.SubElement(audio, "samplecharacteristics")
        P.add_text(sample, "depth", 16)
        P.add_text(sample, "samplerate", 48_000)
        P.add_text(audio, "channelcount", 2)
        source_track = ET.SubElement(clip, "sourcetrack")
        P.add_text(source_track, "mediatype", "audio")
        P.add_text(source_track, "trackindex", 2)
        placed.append(
            {
                "label": label,
                "path": str(path),
                "source_time_us": source_us,
                "timeline_start_frame": start_frame,
                "snapped_to_subtitle": snapped,
            }
        )
    return track, placed, dropped


def make_preview_bgm_bed(
    bgm: Path,
    *,
    run_us: int,
    output: Path,
    gain: str,
    fade_seconds: float,
) -> None:
    run_seconds = run_us / 1_000_000
    fade_duration = min(max(0.1, fade_seconds), max(0.1, run_seconds))
    fade_start = max(0.0, run_seconds - fade_duration)
    run_command(
        [
            "ffmpeg",
            "-y",
            "-stream_loop",
            "-1",
            "-i",
            str(bgm),
            "-t",
            f"{run_seconds:.6f}",
            "-af",
            f"volume={gain},afade=t=out:st={fade_start:.6f}:d={fade_duration:.6f}",
            "-ar",
            "48000",
            "-ac",
            "2",
            "-c:a",
            "aac",
            "-b:a",
            "256k",
            str(output),
        ],
        timeout=3600,
    )
    if not output.is_file() or output.stat().st_size == 0:
        raise RuntimeError("BGM preview bed was not created")


def build_bgm_track(path: Path, run_frames: int, rate: P.FrameRate) -> ET.Element:
    track = ET.Element("track")
    clip = ET.SubElement(track, "clipitem", {"id": "bgm0"})
    P.add_text(clip, "name", path.name)
    P.add_text(clip, "enabled", "TRUE")
    P.add_text(clip, "duration", run_frames)
    add_rate(clip, rate)
    P.add_text(clip, "start", 0)
    P.add_text(clip, "end", run_frames)
    P.add_text(clip, "in", 0)
    P.add_text(clip, "out", run_frames)
    file_element = ET.SubElement(clip, "file", {"id": "bgmfile"})
    P.add_text(file_element, "name", path.name)
    P.add_text(file_element, "pathurl", path.as_uri())
    add_rate(file_element, rate)
    P.add_text(file_element, "duration", run_frames)
    media = ET.SubElement(file_element, "media")
    audio = ET.SubElement(media, "audio")
    sample = ET.SubElement(audio, "samplecharacteristics")
    P.add_text(sample, "depth", 16)
    P.add_text(sample, "samplerate", 48_000)
    P.add_text(audio, "channelcount", 2)
    source_track = ET.SubElement(clip, "sourcetrack")
    P.add_text(source_track, "mediatype", "audio")
    P.add_text(source_track, "trackindex", 3)
    return track


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--se-plan", default=None)
    parser.add_argument("--se-root", default=None)
    parser.add_argument("--snap-tolerance-ms", type=int, default=300)
    parser.add_argument("--noise", default="-30dB")
    parser.add_argument("--silence-duration", "--d", type=float, default=0.35)
    parser.add_argument("--padding", "--pad", type=float, default=0.06)
    parser.add_argument("--minimum-keep", "--minkeep", type=float, default=0.12)
    parser.add_argument("--max-chars", "--maxchars", type=int, default=18)
    parser.add_argument("--outdir", default=None)
    parser.add_argument("--no-subtitles", "--no-telop", action="store_true")
    parser.add_argument("--transcript-json", "--words-json", default=None)
    parser.add_argument("--dictionary-json", default=None)
    parser.add_argument("--bgm", default=None)
    parser.add_argument("--bgm-gain", default="0.18")
    parser.add_argument("--bgm-fade-seconds", type=float, default=2.0)
    parser.add_argument("--allow-vfr", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = Path(args.input).expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"Input not found: {source}")
    output_dir = Path(args.outdir).expanduser().resolve() if args.outdir else source.parent
    output_dir.mkdir(parents=True, exist_ok=True)
    base = source.stem

    media = P.probe_media(source)
    if media.is_vfr and not args.allow_vfr:
        raise SystemExit("VFR detected. Normalize with the approved CFR profile before editing.")
    silences = P.detect_silences(source, args.noise, args.silence_duration, media.duration_us)
    blocks, run_frames = P.build_keep_blocks(
        silences,
        media,
        padding_us=round(args.padding * 1_000_000),
        minimum_keep_us=round(args.minimum_keep * 1_000_000),
    )
    if not blocks:
        raise SystemExit("No keep blocks remain")

    srt_text = ""
    subtitle_path: Path | None = None
    subtitle_starts: list[int] = []
    if not args.no_subtitles and args.transcript_json:
        transcript = load_json(args.transcript_json)
        if not isinstance(transcript, dict):
            raise ValueError("Transcript JSON must be an object")
        replacements = P.load_replacements(args.dictionary_json)
        srt_text, _ = P.make_srt(
            P.parse_transcript_words(transcript),
            blocks,
            run_frames,
            media.frame_rate,
            max_chars=args.max_chars,
            boundary_tolerance_us=300_000,
            replacements=replacements,
        )
        subtitle_path = output_dir / f"{base}_telop.srt"
        atomic_write_text(subtitle_path, srt_text)
        subtitle_starts = parse_srt_start_frames(srt_text, media.frame_rate)

    base_xml = P.build_fcp7_xml(media, blocks, run_frames, "AI_Edit")
    root = ET.fromstring(base_xml.split("<!DOCTYPE xmeml>\n", 1)[1])
    audio_parent = root.find("./sequence/media/audio")
    if audio_parent is None:
        raise RuntimeError("Generated XML is missing the sequence audio node")

    placed: list[dict] = []
    dropped: list[dict] = []
    if args.se_plan:
        placements = load_se_plan(Path(args.se_plan).expanduser().resolve())
        se_track, placed, dropped = build_se_track(
            placements,
            blocks,
            media.frame_rate,
            subtitle_starts=subtitle_starts,
            snap_tolerance_ms=args.snap_tolerance_ms,
            se_root=Path(args.se_root).expanduser().resolve() if args.se_root else None,
        )
        audio_parent.append(se_track)

    bgm_bed: Path | None = None
    if args.bgm:
        bgm = Path(args.bgm).expanduser().resolve()
        if not bgm.is_file():
            raise SystemExit(f"BGM not found: {bgm}")
        bgm_bed = output_dir / f"{base}_bgm_bed.m4a"
        make_preview_bgm_bed(
            bgm,
            run_us=media.frame_rate.frames_to_microseconds(run_frames),
            output=bgm_bed,
            gain=args.bgm_gain,
            fade_seconds=args.bgm_fade_seconds,
        )
        audio_parent.append(build_bgm_track(bgm_bed, run_frames, media.frame_rate))

    ET.indent(root, space="  ")
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n'
        + ET.tostring(root, encoding="unicode")
        + "\n"
    )
    ET.fromstring(xml.split("<!DOCTYPE xmeml>\n", 1)[1])
    xml_path = output_dir / f"{base}_edit.xml"
    atomic_write_text(xml_path, xml)

    timeline_map_path = output_dir / f"{base}_timeline-map.json"
    atomic_write_json(timeline_map_path, P.timeline_map_document(media, blocks, run_frames))
    report = {
        "schema_name": "premiere-edit-report",
        "schema_version": "2.0",
        "source": str(source),
        "xml": str(xml_path),
        "srt": str(subtitle_path) if subtitle_path else None,
        "timeline_map": str(timeline_map_path),
        "se_placed": placed,
        "se_dropped": dropped,
        "bgm_preview_bed": str(bgm_bed) if bgm_bed else None,
        "frame_rate": media.frame_rate.to_dict(),
        "timeline_duration_frames": run_frames,
    }
    report_path = output_dir / f"{base}_edit-report.json"
    atomic_write_json(report_path, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
