#!/usr/bin/env python3
"""Transcribe media and emit a reusable word-timestamp JSON artifact.

This is the corrected/adopted version of the original transcribe.py.  It keeps
its simple faster-whisper workflow while adding cache identity, selectable
runtime settings, atomic writes, and a stable JSON envelope.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from common import atomic_write_json, sha256_file


def build_cache_key(
    source_sha256: str,
    *,
    model: str,
    language: str,
    device: str,
    compute_type: str,
    vad_filter: bool,
    condition_on_previous_text: bool,
) -> str:
    payload = {
        "source_sha256": source_sha256,
        "provider": "faster-whisper",
        "model": model,
        "language": language,
        "device": device,
        "compute_type": compute_type,
        "vad_filter": vad_filter,
        "condition_on_previous_text": condition_on_previous_text,
        "word_timestamps": True,
    }
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--model", default="small")
    parser.add_argument("--language", default="ja")
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--compute-type", default="int8")
    parser.add_argument("--vad-filter", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument(
        "--condition-on-previous-text",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    parser.add_argument("--out", default=None)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = Path(args.input).expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"Input not found: {source}")

    output = Path(args.out).expanduser().resolve() if args.out else source.with_name(
        source.stem + "_transcript.json"
    )
    source_sha256 = sha256_file(source)
    cache_key = build_cache_key(
        source_sha256,
        model=args.model,
        language=args.language,
        device=args.device,
        compute_type=args.compute_type,
        vad_filter=args.vad_filter,
        condition_on_previous_text=args.condition_on_previous_text,
    )

    if output.exists() and not args.force:
        try:
            cached = json.loads(output.read_text(encoding="utf-8"))
            if cached.get("cache_key") == cache_key:
                print(f"CACHE HIT: {output}")
                return 0
        except (OSError, json.JSONDecodeError):
            pass

    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise SystemExit(
            "faster-whisper is not installed. Install the pinned dependency before running."
        ) from exc

    model = WhisperModel(
        args.model,
        device=args.device,
        compute_type=args.compute_type,
    )
    segments_iter, info = model.transcribe(
        str(source),
        language=args.language,
        vad_filter=args.vad_filter,
        word_timestamps=True,
        condition_on_previous_text=args.condition_on_previous_text,
    )

    segments: list[dict[str, object]] = []
    for segment in segments_iter:
        words = [
            {
                "text": word.word,
                "start_us": round(float(word.start) * 1_000_000),
                "end_us": round(float(word.end) * 1_000_000),
            }
            for word in (segment.words or [])
            if word.start is not None and word.end is not None
        ]
        item = {
            "start_us": round(float(segment.start) * 1_000_000),
            "end_us": round(float(segment.end) * 1_000_000),
            "text": segment.text.strip(),
            "words": words,
        }
        segments.append(item)
        print(
            f"[{item['start_us']/1_000_000:7.2f}-{item['end_us']/1_000_000:7.2f}] "
            f"{item['text']}",
            flush=True,
        )

    document = {
        "schema_name": "transcript-raw",
        "schema_version": "2.0",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "provider": "faster-whisper",
        "model": args.model,
        "language": args.language,
        "device": args.device,
        "compute_type": args.compute_type,
        "vad_filter": args.vad_filter,
        "condition_on_previous_text": args.condition_on_previous_text,
        "source_path": str(source),
        "source_sha256": source_sha256,
        "cache_key": cache_key,
        "duration_us": round(float(info.duration) * 1_000_000),
        "segments": segments,
    }
    atomic_write_json(output, document)
    print(f"DONE {len(segments)} segments -> {output}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
