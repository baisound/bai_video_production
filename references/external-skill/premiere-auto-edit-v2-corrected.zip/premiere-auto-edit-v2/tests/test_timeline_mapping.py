from fractions import Fraction
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from common import FrameRate
from ppro_autocut import KeepBlock, locate_source_time, source_us_to_timeline_frame
from edit_pipeline import nearest_with_tolerance


def test_exact_ntsc_mapping():
    rate = FrameRate(30000, 1001)
    assert rate.timebase == 30
    assert rate.ntsc is True
    assert rate.microseconds_to_frames(1_001_000) == 30
    assert rate.frames_to_microseconds(30) == 1_001_000


def test_source_to_timeline_mapping_after_cut():
    rate = FrameRate(30, 1)
    block = KeepBlock("B1", 2_000_000, 5_000_000, 60, 150, 0, 90)
    assert source_us_to_timeline_frame(3_000_000, block, rate) == 30


def test_locate_respects_tolerance():
    block = KeepBlock("B1", 1_000_000, 2_000_000, 30, 60, 0, 30)
    found, adjusted = locate_source_time(800_000, [block], tolerance_us=300_000)
    assert found == block
    assert adjusted == 1_000_000
    not_found, _ = locate_source_time(500_000, [block], tolerance_us=300_000)
    assert not_found is None


def test_snap_has_distance_limit():
    value, snapped = nearest_with_tolerance(100, [130], 20)
    assert value == 100 and not snapped
    value, snapped = nearest_with_tolerance(100, [115], 20)
    assert value == 115 and snapped
