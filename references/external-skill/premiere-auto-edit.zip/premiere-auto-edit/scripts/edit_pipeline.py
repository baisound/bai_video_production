#!/usr/bin/env python3
"""
edit_pipeline.py — 「素材を渡して編集して」一括パイプライン
  入力動画 → 無音カット + テロップ(SRT) + SE自動配置 を、1本のPremiere XMLに統合出力。

  出力: <name>_edit.xml   … V1=カット映像 / A1=カット元音声 / A2=SE（カット後座標に整合）
        <name>_telop.srt  … テロップ（カット後タイムライン整合）

  SE配置: --se-plan の JSON（[{"t":元秒,"se":"相対パス","label":...}]）をカット後座標へ写像。
          t がカット(無音)区間に入る場合は 0.30秒以内で隣接ブロックにスナップ、超過なら除外。
  使い方: python3 edit_pipeline.py --input <movie> --se-plan se_plan.json
          (ppro_autocut.py と同ディレクトリで実行 / オプションは ppro_autocut と同じ)
"""
import argparse, os, sys, json, subprocess, re, urllib.parse
import urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ppro_autocut as P

SE_ROOT = ""  # se_planは絶対パス推奨。相対パス時のみ基準に使う
R = "<rate><timebase>30</timebase><ntsc>TRUE</ntsc></rate>"

def se_duration(path):
    r = subprocess.run(["ffprobe","-v","quiet","-show_entries","format=duration",
        "-of","default=noprint_wrappers=1:nokey=1",path],capture_output=True,text=True).stdout.strip()
    return float(r)

def locate(t, blocks, TOL=0.30):
    for i,b in enumerate(blocks):
        if b["s0"]<=t<=b["s1"]: return i,t
    best=None; bd=1e9; bt=t
    for i,b in enumerate(blocks):
        if t<b["s0"]: d=b["s0"]-t; tt=b["s0"]
        else: d=t-b["s1"]; tt=b["s1"]
        if d<bd: bd=d; best=i; bt=tt
    return (best,bt) if bd<=TOL else (None,t)

def mapf(t, bi, blocks, fps):
    b=blocks[bi]; tt=min(max(t,b["s0"]),b["s1"])
    return b["ts"]+(P.f(tt,fps)-b["sin"])

def parse_srt_starts(srt_text, fps):
    # SRTの各行の開始タイムコード → カット後フレーム のソート済みリスト
    starts=[]
    for m in re.finditer(r"(\d\d):(\d\d):(\d\d),(\d\d\d)\s*-->", srt_text):
        h,mm,s,ms=map(int,m.groups())
        sec=h*3600+mm*60+s+ms/1000.0
        starts.append(P.f(sec,fps))
    return sorted(set(starts))

def build_se_track(plan, blocks, fps, telop_starts=None):
    clips=[]; placed=[]; dropped=[]
    for i,item in enumerate(plan):
        se=item["se"]
        ap=se if os.path.isabs(se) else os.path.join(SE_ROOT, se)  # 絶対パスならそのまま使う（第三者のSEフォルダ対応）
        if not os.path.exists(ap):
            dropped.append((item.get("label",item["se"]),"ファイル無し")); continue
        bi,ts=locate(item["t"],blocks)
        if bi is None:
            dropped.append((item.get("label",item["se"]),"カット区間内")); continue
        start=mapf(ts,bi,blocks,fps)
        # テロップが出る瞬間にSEを合わせる: 最も近いテロップ開始フレームへスナップ
        snap_note=""
        if telop_starts:
            nearest=min(telop_starts,key=lambda s:abs(s-start))
            if nearest!=start: snap_note=f" (テロップ合わせ {(nearest-start)/fps:+.2f}s)"
            start=nearest
        fdur=max(1,P.f(se_duration(ap),fps)); end=start+fdur
        name=os.path.basename(ap).replace("&","&amp;")
        pathurl="file://"+urllib.parse.quote(ap)
        fid=f"sefile{i}"
        clips.append(
            f'<clipitem id="se{i}"><name>{name}</name><enabled>TRUE</enabled><duration>{fdur}</duration>{R}'
            f'<start>{start}</start><end>{end}</end><in>0</in><out>{fdur}</out>'
            f'<file id="{fid}"><name>{name}</name><pathurl>{pathurl}</pathurl>{R}<duration>{fdur}</duration>'
            f'<media><audio><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics><channelcount>2</channelcount></audio></media></file>'
            f'<sourcetrack><mediatype>audio</mediatype><trackindex>2</trackindex></sourcetrack></clipitem>')
        placed.append((item.get("label",item["se"])+snap_note, start/fps))
    return "<track>"+"".join(clips)+"</track>", placed, dropped

def make_bgm_bed(bgm, run_sec, outdir, base, gain):
    # BGMをカット後尺ぴったりにループ/トリム＋音量down＋末尾フェードアウトした「BGMベッド」を書き出す
    bed=os.path.join(outdir, base+"_bgm_bed.m4a")
    fo=max(0.1, run_sec-2.0)
    subprocess.run(["ffmpeg","-y","-stream_loop","-1","-i",bgm,"-t",f"{run_sec:.3f}",
        "-af",f"volume={gain},afade=t=out:st={fo:.2f}:d=2.0","-ar","48000","-ac","2",bed],
        capture_output=True)
    return bed

def build_bgm_track(bedpath, run, fps):
    name=os.path.basename(bedpath).replace("&","&amp;")
    pathurl="file://"+urllib.parse.quote(bedpath)
    clip=(f'<clipitem id="bgm0"><name>{name}</name><enabled>TRUE</enabled><duration>{run}</duration>{R}'
          f'<start>0</start><end>{run}</end><in>0</in><out>{run}</out>'
          f'<file id="bgmfile"><name>{name}</name><pathurl>{pathurl}</pathurl>{R}<duration>{run}</duration>'
          f'<media><audio><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics><channelcount>2</channelcount></audio></media></file>'
          f'<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack></clipitem>')
    return "<track>"+clip+"</track>"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True)
    ap.add_argument("--se-plan",default=None)
    ap.add_argument("--noise",default="-30dB"); ap.add_argument("--d",type=float,default=0.35)
    ap.add_argument("--pad",type=float,default=0.06); ap.add_argument("--minkeep",type=float,default=0.12)
    ap.add_argument("--maxchars",type=int,default=18); ap.add_argument("--model",default="small")
    ap.add_argument("--outdir",default=None); ap.add_argument("--no-telop",action="store_true")
    ap.add_argument("--reuse-telop",action="store_true",help="既存の_telop.srtを再利用（再文字起こししない）")
    ap.add_argument("--words-json",default=None,help="transcribe.pyのtranscript.jsonを使う（再文字起こし不要）")
    ap.add_argument("--bgm",default=None,help="BGMファイルのパス（指定するとA3にBGMベッドを敷く）")
    ap.add_argument("--bgm-gain",default="0.18",help="BGM音量(線形 例:0.18) または dB(例:-15dB)")
    a=ap.parse_args()
    src=a.input
    if not os.path.exists(src): sys.exit("入力が見つかりません: "+src)
    outdir=a.outdir or os.path.dirname(src); base=os.path.splitext(os.path.basename(src))[0]
    fps=P.get_fps(src); w,h=P.get_dims(src); total=P.get_duration(src); total_frames=P.f(total,fps)
    print(f"fps={fps:.3f} {w}x{h} {total:.1f}s")
    sil=P.detect_silences(src,a.noise,a.d)
    blocks,run=P.build_blocks(sil,total,fps,a.pad,a.minkeep)
    print(f"無音{len(sil)}区間 → keep{len(blocks)}ブロック / カット後 {run/fps:.1f}秒 (除去 {(total_frames-run)/fps:.1f}秒)")

    # ① テロップ（SEのスナップ先になるので先に作る）
    srtpath=os.path.join(outdir,base+"_telop.srt"); telop_starts=None
    if not a.no_telop:
        if a.words_json and os.path.exists(a.words_json):
            d=json.load(open(a.words_json,encoding="utf-8"))
            words=[(w["start"],w["end"],w["w"]) for s in d["segments"] for w in s.get("words",[])]
            if not words: words=[(s["start"],s["end"],s["text"]) for s in d["segments"]]
            srt,nlines=P.make_srt(words,blocks,run,fps,a.maxchars); open(srtpath,"w").write(srt)
            print(f"SRT(transcript.json流用): {srtpath} (テロップ{nlines}枚)")
        elif a.reuse_telop and os.path.exists(srtpath):
            srt=open(srtpath,encoding="utf-8").read(); nlines=srt.count("-->")
            print(f"SRT再利用: {srtpath} (テロップ{nlines}枚)")
        else:
            words=P.transcribe_words(src,a.model)
            srt,nlines=P.make_srt(words,blocks,run,fps,a.maxchars)
            open(srtpath,"w").write(srt)
            print(f"SRT: {srtpath} (テロップ{nlines}枚)")
        telop_starts=parse_srt_starts(srt,fps)

    # ② カット映像/音声XML（V1/A1）
    base_xml=P.make_xml(src,blocks,run,w,h,total_frames)
    base_xml=base_xml.replace("<name>AI_AutoCut</name>","<name>AI_Edit</name>",1)

    # ③ SE（テロップ出現タイミングにスナップ）を A2 として合流
    if a.se_plan:
        plan=json.load(open(a.se_plan,encoding="utf-8"))
        se_track,placed,dropped=build_se_track(plan,blocks,fps,telop_starts)
        base_xml=base_xml.replace("</track></audio>","</track>"+se_track+"</audio>",1)
        print(f"SE配置: {len(placed)}個 (除外{len(dropped)}) / テロップ合わせ={'ON' if telop_starts else 'OFF'}")
        for lab,t in placed: print(f"   {int(t//60)}:{t%60:05.2f}  {lab}")
        for lab,why in dropped: print(f"   除外: {lab} ({why})")

    # ④ BGM（A3）: カット後尺ぴったりのベッドを敷く
    if a.bgm:
        if not os.path.exists(a.bgm):
            print("⚠ BGMが見つかりません:",a.bgm)
        else:
            bed=make_bgm_bed(a.bgm, run/fps, outdir, base, a.bgm_gain)
            base_xml=base_xml.replace("</track></audio>","</track>"+build_bgm_track(bed,run,fps)+"</audio>",1)
            print(f"BGM: {os.path.basename(a.bgm)} → ベッド{run/fps:.1f}s 音量{a.bgm_gain} (末尾2sフェードアウト)")

    xmlpath=os.path.join(outdir,base+"_edit.xml"); open(xmlpath,"w").write(base_xml)
    import xml.dom.minidom as M; M.parseString(base_xml)
    print("XML:",xmlpath)
    print("完了。Premiereで _edit.xml→カット映像+音声+SE、_telop.srt→テロップ。")

if __name__=="__main__": main()
