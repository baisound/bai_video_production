# Premiere Auto Edit v2 — Corrected Reference Implementation

This package is a corrected implementation derived from the user-provided
license-free `premiere-auto-edit` skill.  It is intended as a reference worker
for the AI video production design document, not as an implementation
authorization under AI Development OS.

## Adopted concepts

- AI/Planner writes an SE placement plan; deterministic Python executes it.
- Silence complement becomes keep blocks.
- Source time is mapped to the edited timeline through one shared map.
- Word timestamps are remapped after cuts before SRT generation.
- FCP7 XML provides a Premiere-compatible rough-edit adapter.
- Preview BGM is looped/trimmed and kept separate from final loudness mastering.

## Main corrections

- exact rational FPS and NTSC handling;
- VFR detection and fail-safe stop;
- checked/timeout-bound subprocess execution;
- XML DOM generation rather than string insertion;
- configurable replacement dictionary;
- bounded SE-to-caption snapping;
- atomic JSON/XML/SRT writes;
- transcript cache key and reusable transcript envelope;
- timeline-map and structured report artifacts.

## Dependencies

- Python 3.11+
- ffmpeg / ffprobe
- faster-whisper (only for `transcribe.py`)
- pytest (tests only)

## Example

```bash
python scripts/transcribe.py --input input.mp4 --model small
python scripts/edit_pipeline.py \
  --input input.mp4 \
  --transcript-json input_transcript.json \
  --dictionary-json dictionary.example.json \
  --se-plan se-plan.json \
  --se-root /path/to/se \
  --bgm /path/to/bgm.wav
```

Run tests:

```bash
pytest -q
```
